Karmvir Singh Dhaliwal 
30025474
CPSC 418 A3

I am submitting 1 file for this assignment, namely basic_handshake.py, a python file that walks through a basic ttp secure file transfer protocol.

I have implemented the functions: server_prepare, ttp_prepare, decrypt_and_verify, pad_encrypt_then_mac, decrypt, encrypt, sign, keypair, and modulus functions.

I have not implemented: client_protocol, server_protocol, key_request, sign_request, ttp_send_key, and ttp_sign.

Of the functions I have implemented, there are no known bugs.  